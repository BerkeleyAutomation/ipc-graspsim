Used for collision checking during grasp initialization
`finger.stl` and `round_pad.obj` used for collision checking 
`yumi_metal_spline.yaml` and `area_contact_generator.yaml`, used for collision checking

`round_pad.msh`, used for IPC-GraspSim simulation (generated from `round_pad.obj`)
